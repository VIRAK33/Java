package com.i4.itc;
import java.util.Scanner;

public class TP03_1 {

    public static void main(String[] args) {
        System.out.println("Your name is:");
        final Scanner s = new Scanner(System.in);
        final String name = s.nextLine();
        System.out.println("Your name is:"+ name);

    }
}
