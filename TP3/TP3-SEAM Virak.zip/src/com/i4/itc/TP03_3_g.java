package com.i4.itc;

public class TP03_3_g {
    public static void main(String[] a){
        System.out.println("*****");
        System.out.println(" ***");
        System.out.println("  *");
        System.out.println(" ***");
        System.out.println("*****");
    }
}
