package com.i4.itc;


public class TP03_2 {
    public static void main(String[] a){
        System.out.println("\\n"+"\t\t\t\t\t\t\t"+"Line break.");
        System.out.println("\\b"+"\t\t\t\t\t"+"Erase one character.");
        System.out.println("\\t"+"\t\t\t\t\t\t\t"+"Tabulation");
        System.out.println("\\'"+"\t\t\t\t\t\t\t"+"Single Quote.");
        System.out.println("\\\"" +"\t\t\t\t\t\t\t"+"Double Quote.");
        System.out.println("\\"+"\t\t\t\t\t\t\t"+"\\ Sign.");
        System.out.println("\\\\"+"\t\t\t\t\t\t\t"+"\\\\ Sing.");
        System.out.println("//"+"\t\t\t\t\t\t\t"+"Line Comment.");
        System.out.println("/*...*/"+"\t\t\t\t\t\t"+"Block Comment.");






    }


}
