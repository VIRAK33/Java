package com.i4.itc;

import javax.swing.*;

public class Test {
    private JTable table1;
}
